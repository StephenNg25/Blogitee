<?php
include 'partials/header.php';
?>


    <section class="empty_page">
        <h2>Services Page</h2>
    </section>
     
<?php
include 'partials/footer.php';
?>

