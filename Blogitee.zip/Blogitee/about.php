<?php
include 'partials/header.php';
?>


    <section class="empty_page">
        <h2>About Page</h2>
    </section>

<?php
include 'partials/footer.php';
?>

    